"""Test Parity N=8 with the Spin Phase Wave (Thermodynamic Onde de Phase)."""
import os
import sys
import time
import csv
from dataclasses import dataclass
from typing import Dict, List, Tuple

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F


def _repo_root() -> str:
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _ensure_import_paths():
    root = _repo_root()
    liar_dir = os.path.join(root, "Logical Isring-Attractor with Relational-Attention")
    if liar_dir not in sys.path:
        sys.path.insert(0, liar_dir)


def _bits_to_spins(bits01: torch.Tensor) -> torch.Tensor:
    return bits01 * 2.0 - 1.0


def _parity_label(bits01: torch.Tensor) -> torch.Tensor:
    parity01 = (bits01.sum(dim=1) % 2).float()
    y_spin = parity01 * 2.0 - 1.0
    return y_spin.unsqueeze(1)


def _sample_batch(batch_size: int, n_bits: int, device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
    bits = torch.randint(0, 2, (batch_size, n_bits), device=device).float()
    x = _bits_to_spins(bits)
    y = _parity_label(bits)
    return x, y


@dataclass
class EvalRow:
    seed: int
    wave_gate_init_raw: float
    lr: float
    struct_coeff: float
    k: float
    beta0: float
    step: int
    loss: float
    acc: float
    best_acc: float
    wave_gate: float
    phase_freq_base: float
    phase_freq_adapt_norm: float
    phase_shift: float
    lambda_wave: float
    wave_penalty: float
    beta_mean: float
    struct_eff: float


@dataclass
class RunSummary:
    seed: int
    wave_gate_init_raw: float
    lr: float
    struct_coeff: float
    k: float
    beta0: float
    best_acc: float
    last_acc: float
    seconds: float
    wave_gate_last: float
    phase_freq_base_last: float
    phase_freq_adapt_norm_last: float
    lambda_wave_last: float
    wave_penalty_last: float
    beta_mean_last: float
    struct_eff_last: float


def _write_eval_csv(path: str, rows: List[EvalRow]):
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "seed",
            "wave_gate_init_raw",
            "lr",
            "struct_coeff",
            "k",
            "beta0",
            "step",
            "loss",
            "acc",
            "best_acc",
            "wave_gate",
            "phase_freq_base",
            "phase_freq_adapt_norm",
            "phase_shift",
            "lambda_wave",
            "wave_penalty",
            "beta_mean",
            "struct_eff",
        ])
        for r in rows:
            w.writerow([
                r.seed,
                f"{r.wave_gate_init_raw:.6f}",
                f"{r.lr:.6f}",
                f"{r.struct_coeff:.8f}",
                f"{r.k:.6f}",
                f"{r.beta0:.6f}",
                r.step,
                f"{r.loss:.12f}",
                f"{r.acc:.6f}",
                f"{r.best_acc:.6f}",
                f"{r.wave_gate:.6f}",
                f"{r.phase_freq_base:.6f}",
                f"{r.phase_freq_adapt_norm:.6f}",
                f"{r.phase_shift:.6f}",
                f"{r.lambda_wave:.6f}",
                f"{r.wave_penalty:.12f}",
                f"{r.beta_mean:.6f}",
                f"{r.struct_eff:.8f}",
            ])


def _write_summary_csv(path: str, rows: List[RunSummary]):
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "seed",
            "wave_gate_init_raw",
            "lr",
            "struct_coeff",
            "k",
            "beta0",
            "best_acc",
            "last_acc",
            "seconds",
            "wave_gate_last",
            "phase_freq_base_last",
            "phase_freq_adapt_norm_last",
            "lambda_wave_last",
            "wave_penalty_last",
            "beta_mean_last",
            "struct_eff_last",
        ])
        for r in rows:
            w.writerow([
                r.seed,
                f"{r.wave_gate_init_raw:.6f}",
                f"{r.lr:.6f}",
                f"{r.struct_coeff:.8f}",
                f"{r.k:.6f}",
                f"{r.beta0:.6f}",
                f"{r.best_acc:.6f}",
                f"{r.last_acc:.6f}",
                f"{r.seconds:.4f}",
                f"{r.wave_gate_last:.6f}",
                f"{r.phase_freq_base_last:.6f}",
                f"{r.phase_freq_adapt_norm_last:.6f}",
                f"{r.lambda_wave_last:.6f}",
                f"{r.wave_penalty_last:.12f}",
                f"{r.beta_mean_last:.6f}",
                f"{r.struct_eff_last:.8f}",
            ])


def _make_figures(summary_csv: str, eval_csv: str, out_dir: str):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    by_init: Dict[float, List[float]] = {}
    with open(summary_csv, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            init_raw = float(row["wave_gate_init_raw"])
            best = float(row["best_acc"]) * 100.0
            by_init.setdefault(init_raw, []).append(best)

    inits = sorted(by_init.keys())
    means = [sum(by_init[v]) / max(1, len(by_init[v])) for v in inits]
    mins = [min(by_init[v]) for v in inits]
    maxs = [max(by_init[v]) for v in inits]

    fig = plt.figure(figsize=(7.5, 3.6))
    ax = fig.add_subplot(1, 1, 1)
    ax.plot(inits, means, marker="o", label="mean(best_acc)")
    ax.fill_between(inits, mins, maxs, alpha=0.2, label="min..max")
    ax.set_xlabel("wave_gate_init_raw")
    ax.set_ylabel("Best test accuracy (%)")
    ax.set_ylim(0, 105)
    ax.grid(True, alpha=0.25)
    ax.set_title("Parity N=8 (phase-wave): best accuracy vs wave_gate_init_raw")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "phase_wave_parity_best_acc_vs_init.png"), dpi=200)
    plt.close(fig)

    fig = plt.figure(figsize=(7.8, 3.8))
    ax = fig.add_subplot(1, 1, 1)

    series: Dict[Tuple[int, float, float, float, float], List[Tuple[int, float]]] = {}
    with open(eval_csv, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = (
                int(row["seed"]),
                float(row["wave_gate_init_raw"]),
                float(row["lr"]),
                float(row["struct_coeff"]),
                float(row["best_acc"]),
            )
            series.setdefault(key, []).append((int(row["step"]), float(row["acc"]) * 100.0))

    top_k = 12
    keys_sorted = sorted(series.keys(), key=lambda k: (k[4], -k[2], -k[3]), reverse=True)
    shown = 0
    for key in keys_sorted:
        if shown >= top_k:
            break
        pts = series[key]
        pts_sorted = sorted(pts, key=lambda p: p[0])
        xs = [p[0] for p in pts_sorted]
        ys = [p[1] for p in pts_sorted]
        seed, init_raw, lr, struct_coeff, best_acc = key
        ax.plot(
            xs,
            ys,
            alpha=0.85,
            linewidth=1.25,
            label=f"seed={seed},init={init_raw:g},lr={lr:g},struct={struct_coeff:g},best={best_acc*100:.1f}%",
        )
        shown += 1

    ax.set_xlabel("training step")
    ax.set_ylabel("test accuracy (%)")
    ax.set_ylim(0, 105)
    ax.grid(True, alpha=0.25)
    ax.set_title("Parity N=8 (phase-wave): example accuracy trajectories")
    ax.legend(fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "phase_wave_parity_trajectories.png"), dpi=200)
    plt.close(fig)


def run_once(
    *,
    seed: int,
    wave_gate_init_raw: float,
    lr: float,
    struct_coeff: float,
    k: float,
    beta0: float,
    max_order: int,
    n_bits: int,
    max_steps: int,
    latent_dim: int,
    steps: int,
    batch_size: int,
    eval_every: int,
    eval_batch: int,
    device: torch.device,
) -> Tuple[RunSummary, List[EvalRow]]:
    from liar_neuron import LIARNeuron

    torch.manual_seed(seed)
    t0 = time.time()

    model = LIARNeuron(
        in_features=n_bits,
        out_features=1,
        max_steps=max_steps,
        latent_dim=latent_dim,
        max_order=max_order,
    ).to(device)

    with torch.no_grad():
        model.wave_gate_raw.fill_(float(wave_gate_init_raw))

    opt = optim.Adam(model.parameters(), lr=lr)
    crit = nn.MSELoss()

    best_acc = 0.0
    last_acc = 0.0
    out_rows: List[EvalRow] = []

    last_beta_mean = 0.0
    last_struct_eff = float(struct_coeff)

    def _lambda_wave_value(m: nn.Module) -> float:
        if not hasattr(m, "lambda_wave_raw"):
            return 0.0
        with torch.no_grad():
            return float(F.softplus(m.lambda_wave_raw).detach().item())

    for t in range(steps):
        x, y = _sample_batch(batch_size, n_bits, device)
        opt.zero_grad()
        out = model(x)
        mse = crit(out, y)
        structural = model.get_structural_penalty()
        wave_penalty = model.get_wave_penalty() if hasattr(model, "get_wave_penalty") else torch.tensor(0.0, device=mse.device)
        if hasattr(model, "beta"):
            with torch.no_grad():
                beta_mean = torch.mean(model.beta).detach()
                gate = torch.sigmoid((beta_mean - float(beta0)) * float(k))
            struct_eff = struct_coeff * float(gate.item())
        else:
            struct_eff = struct_coeff
        loss = mse + struct_eff * structural + wave_penalty
        loss.backward()
        opt.step()

        if (t + 1) % eval_every == 0 or (t + 1) == steps:
            with torch.no_grad():
                x_t, y_t = _sample_batch(eval_batch, n_bits, device)
                pred = (model(x_t) > 0).float() * 2.0 - 1.0
                acc = (pred == y_t).float().mean().item()
                best_acc = max(best_acc, acc)
                last_acc = acc

                if hasattr(model, "beta"):
                    beta_mean_val = float(torch.mean(model.beta).detach().item())
                    struct_eff_val = float(struct_coeff * torch.sigmoid((torch.tensor(beta_mean_val, device=device) - float(beta0)) * float(k)).item())
                else:
                    beta_mean_val = 0.0
                    struct_eff_val = float(struct_coeff)

                last_beta_mean = beta_mean_val
                last_struct_eff = struct_eff_val
                lambda_wave_val = _lambda_wave_value(model)
                wave_penalty_val = float((model.get_wave_penalty() if hasattr(model, "get_wave_penalty") else torch.tensor(0.0, device=mse.device)).detach().item())
                out_rows.append(
                    EvalRow(
                        seed=seed,
                        wave_gate_init_raw=wave_gate_init_raw,
                        lr=lr,
                        struct_coeff=struct_coeff,
                        k=float(k),
                        beta0=float(beta0),
                        step=int(t + 1),
                        loss=float(loss.item()),
                        acc=float(acc),
                        best_acc=float(best_acc),
                        wave_gate=float(model.wave_gate.detach().item()),
                        phase_freq_base=float(model.phase_freq_base.detach().item()),
                        phase_freq_adapt_norm=float(torch.norm(model.phase_freq_adapt).detach().item()),
                        phase_shift=float(model.phase_shift.detach().item()),
                        lambda_wave=float(lambda_wave_val),
                        wave_penalty=float(wave_penalty_val),
                        beta_mean=float(beta_mean_val),
                        struct_eff=float(struct_eff_val),
                    )
                )

    seconds = time.time() - t0
    lambda_wave_last = _lambda_wave_value(model)
    wave_penalty_last = float((model.get_wave_penalty() if hasattr(model, "get_wave_penalty") else torch.tensor(0.0, device=device)).detach().item())
    summary = RunSummary(
        seed=seed,
        wave_gate_init_raw=wave_gate_init_raw,
        lr=lr,
        struct_coeff=struct_coeff,
        k=float(k),
        beta0=float(beta0),
        best_acc=float(best_acc),
        last_acc=float(last_acc),
        seconds=float(seconds),
        wave_gate_last=float(model.wave_gate.detach().item()),
        phase_freq_base_last=float(model.phase_freq_base.detach().item()),
        phase_freq_adapt_norm_last=float(torch.norm(model.phase_freq_adapt).detach().item()),
        lambda_wave_last=float(lambda_wave_last),
        wave_penalty_last=float(wave_penalty_last),
        beta_mean_last=float(last_beta_mean),
        struct_eff_last=float(last_struct_eff),
    )
    return summary, out_rows


def main():
    _ensure_import_paths()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out_dir = os.path.join(os.path.dirname(__file__), "figures")
    os.makedirs(out_dir, exist_ok=True)

    n_bits = int(os.environ.get("THERMO_PHASE_WAVE_N_BITS", "8"))
    seeds_str = os.environ.get("THERMO_PHASE_WAVE_SEEDS", "42,123,7")
    seeds = [int(s.strip()) for s in seeds_str.replace(";", ",").split(",") if s.strip()]

    max_order = int(os.environ.get("THERMO_PHASE_WAVE_MAX_ORDER", "3"))
    max_steps = int(os.environ.get("THERMO_PHASE_WAVE_MAX_STEPS", "5"))
    latent_dim = int(os.environ.get("THERMO_PHASE_WAVE_LATENT_DIM", "16"))

    steps = int(os.environ.get("THERMO_PHASE_WAVE_TRAIN_STEPS", "4000"))
    batch_size = int(os.environ.get("THERMO_PHASE_WAVE_BATCH", "256"))
    eval_every = int(os.environ.get("THERMO_PHASE_WAVE_EVAL_EVERY", "500"))
    eval_batch = int(os.environ.get("THERMO_PHASE_WAVE_EVAL_BATCH", "4096"))

    lr_list_str = os.environ.get("THERMO_PHASE_WAVE_LR_LIST", "0.03")
    lr_list = [float(s.strip().replace(",", ".")) for s in lr_list_str.replace(";", ",").split(",") if s.strip()]
    struct_list_str = os.environ.get("THERMO_PHASE_WAVE_STRUCT_LIST", "0.0005")
    struct_list = [float(s.strip().replace(",", ".")) for s in struct_list_str.replace(";", ",").split(",") if s.strip()]
    init_list_str = os.environ.get("THERMO_PHASE_WAVE_INIT_LIST", "-8,-4,-2,0,1,2")
    init_list = [float(s.strip().replace(",", ".")) for s in init_list_str.replace(";", ",").split(",") if s.strip()]

    k_list_str = os.environ.get("THERMO_PHASE_WAVE_K_LIST", "4")
    k_list = [float(s.strip().replace(",", ".")) for s in k_list_str.replace(";", ",").split(",") if s.strip()]
    beta0_list_str = os.environ.get("THERMO_PHASE_WAVE_BETA0_LIST", "1.0")
    beta0_list = [float(s.strip().replace(",", ".")) for s in beta0_list_str.replace(";", ",").split(",") if s.strip()]

    stamp = time.strftime("%Y%m%d_%H%M%S")
    summary_csv = os.path.join(out_dir, f"phase_wave_parity_summary_{stamp}.csv")
    eval_csv = os.path.join(out_dir, f"phase_wave_parity_eval_{stamp}.csv")

    print("=" * 80)
    print(" Parity N=8 : Phase Wave benchmark")
    print("=" * 80)
    print(f" device = {device}")
    print(f" seeds = {seeds}")
    print(f" init_list = {init_list}")
    print(f" lr_list = {lr_list}")
    print(f" struct_list = {struct_list}")
    print(f" k_list = {k_list}")
    print(f" beta0_list = {beta0_list}")
    print(f" out = {out_dir}")

    summaries: List[RunSummary] = []
    eval_rows: List[EvalRow] = []

    for seed in seeds:
        for wave_gate_init_raw in init_list:
            for lr in lr_list:
                for struct_coeff in struct_list:
                    for k in k_list:
                        for beta0 in beta0_list:
                            s, rows = run_once(
                                seed=seed,
                                wave_gate_init_raw=wave_gate_init_raw,
                                lr=lr,
                                struct_coeff=struct_coeff,
                                k=k,
                                beta0=beta0,
                                max_order=max_order,
                                n_bits=n_bits,
                                max_steps=max_steps,
                                latent_dim=latent_dim,
                                steps=steps,
                                batch_size=batch_size,
                                eval_every=eval_every,
                                eval_batch=eval_batch,
                                device=device,
                            )
                            summaries.append(s)
                            eval_rows.extend(rows)
                            print(
                                f" seed={seed:4d} | init_raw={wave_gate_init_raw:>6g} | lr={lr:g} | struct={struct_coeff:g} | k={k:g} | beta0={beta0:g} | "
                                f"best={s.best_acc*100:5.1f}% | last={s.last_acc*100:5.1f}% | wg_last={s.wave_gate_last:.3f} | f_base_last={s.phase_freq_base_last:.3f} | f_adapt_last={s.phase_freq_adapt_norm_last:.3f} | {s.seconds:.1f}s"
                            )

    _write_summary_csv(summary_csv, summaries)
    _write_eval_csv(eval_csv, eval_rows)
    _make_figures(summary_csv, eval_csv, out_dir)
    print("\nCSV summary:")
    print(f"  {summary_csv}")
    print("CSV eval:")
    print(f"  {eval_csv}")
    print("Figures:")
    print(f"  {os.path.join(out_dir, 'phase_wave_parity_best_acc_vs_init.png')}")
    print(f"  {os.path.join(out_dir, 'phase_wave_parity_trajectories.png')}")


if __name__ == "__main__":
    main()
