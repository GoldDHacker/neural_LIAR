import os
import re
import subprocess
import sys
from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass
class SeedResult:
    seed: int
    acc: Optional[float]
    mse: Optional[float]
    early_stop_epoch: Optional[int]
    best_epoch: Optional[int]
    success: Optional[bool]


def _to_float(s: str) -> float:
    return float(s.replace(",", ".").strip())


def run_seed(liar_demo_dir: str, seed: int) -> Tuple[int, str]:
    env = os.environ.copy()
    env["THERMO_DEMO_SEED"] = str(seed)
    p = subprocess.run(
        [sys.executable, os.path.join(liar_demo_dir, "demo_full_adder_adaptive_order.py")],
        capture_output=True,
        text=True,
        cwd=liar_demo_dir,
        env=env,
        check=False,
    )
    out = (p.stdout or "") + "\n" + (p.stderr or "")
    return p.returncode, out


def parse_metrics(text: str, seed: int) -> SeedResult:
    early_stop_re = re.compile(r"\[EARLY_STOP\].*?ep=(\d+)")
    best_epoch_re = re.compile(r"best_epoch\s*=\s*(\d+)")
    acc_re = re.compile(r"Accuracy globale\s*=\s*([0-9]+\.?[0-9]*)%")
    mse_re = re.compile(r"MSE\s*=\s*([0-9]+[\.,]?[0-9]*)")

    early_stop_epoch = None
    best_epoch = None
    acc = None
    mse = None

    m = early_stop_re.search(text)
    if m:
        early_stop_epoch = int(m.group(1))

    m = best_epoch_re.search(text)
    if m:
        best_epoch = int(m.group(1))

    m = acc_re.search(text)
    if m:
        acc = _to_float(m.group(1))

    m = mse_re.search(text)
    if m:
        mse = _to_float(m.group(1))

    success = None
    if acc is not None and mse is not None:
        success = (acc >= 99.999) and (mse <= 0.05)

    return SeedResult(
        seed=seed,
        acc=acc,
        mse=mse,
        early_stop_epoch=early_stop_epoch,
        best_epoch=best_epoch,
        success=success,
    )


def write_csv(path: str, results: List[SeedResult]):
    with open(path, "w", encoding="utf-8") as f:
        f.write("seed,acc,mse,early_stop_epoch,best_epoch,success\n")
        for r in results:
            f.write(
                f"{r.seed},{'' if r.acc is None else r.acc},{'' if r.mse is None else r.mse},"
                f"{'' if r.early_stop_epoch is None else r.early_stop_epoch},"
                f"{'' if r.best_epoch is None else r.best_epoch},"
                f"{'' if r.success is None else (1 if r.success else 0)}\n"
            )


def plot_success_by_seed(fig_path: str, results: List[SeedResult]):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    seeds = [str(r.seed) for r in results]
    flags = [r.success for r in results]

    y = []
    colors = []
    for f in flags:
        if f is True:
            y.append(1)
            colors.append("#2ca02c")
        elif f is False:
            y.append(0)
            colors.append("#d62728")
        else:
            y.append(0)
            colors.append("#7f7f7f")

    fig = plt.figure(figsize=(7.5, 2.8))
    ax = fig.add_subplot(1, 1, 1)
    ax.bar(seeds, y, color=colors)
    ax.set_title("Full-Adder (Adaptive Order) success by seed")
    ax.set_xlabel("Seed")
    ax.set_ylabel("Success")
    ax.set_yticks([0, 1])
    ax.set_ylim(-0.1, 1.1)
    fig.tight_layout()
    fig.savefig(fig_path, dpi=200)
    plt.close(fig)


def main():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    liar_demo_dir = os.path.join(base_dir, "Logical Isring-Attractor with Relational-Attention")

    seeds = list(range(int(os.environ.get("THERMO_SEED_COUNT", "5"))))

    results: List[SeedResult] = []
    for seed in seeds:
        code, out = run_seed(liar_demo_dir, seed)
        r = parse_metrics(out, seed)
        results.append(r)
        ok = "OK" if r.success else "FAIL"
        print(f"seed={seed} | return_code={code} | acc={r.acc} | mse={r.mse} | early_stop={r.early_stop_epoch} | best_epoch={r.best_epoch} | {ok}")

    fig_dir = os.path.join(os.path.dirname(__file__), "figures")
    os.makedirs(fig_dir, exist_ok=True)

    csv_path = os.path.join(fig_dir, "full_adder_adaptive_order_by_seed.csv")
    fig_path = os.path.join(fig_dir, "full_adder_adaptive_order_success_by_seed.png")

    write_csv(csv_path, results)
    plot_success_by_seed(fig_path, results)

    print("[OK] wrote:")
    print(csv_path)
    print(fig_path)


if __name__ == "__main__":
    main()
