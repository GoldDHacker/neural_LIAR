import os
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


@dataclass
class SeedMetrics:
    acc: Optional[float] = None
    mse: Optional[float] = None
    status_success: Optional[bool] = None


def _to_float(s: str) -> float:
    return float(s.replace(",", ".").strip())


def parse_alu_metrics(report_text: str) -> Dict[int, SeedMetrics]:
    # Parse ALU per-seed metrics from blocks under "DÉMARRAGE DU TEST : demo_alu.py".
    # We do NOT trust the trailing "[STATUT DU TEST]" line because the report can
    # contain an inconsistent summary even when strict checks fail.
    lines = report_text.splitlines()

    in_alu = False
    current_seed: Optional[int] = None

    out: Dict[int, SeedMetrics] = {}

    seed_re = re.compile(r"^Seed\s*=\s*(\d+)")
    acc_re = re.compile(r"->\s*Precision atteinte\s*:\s*([0-9]+\s*%|[0-9]+\.?[0-9]*)")
    mse_re = re.compile(r"->\s*MSE Finale\s*:\s*([0-9]+[\.,]?[0-9]*)")

    for line in lines:
        if "DÉMARRAGE DU TEST : demo_alu.py" in line:
            in_alu = True
            current_seed = None
            continue

        if in_alu and "DÉMARRAGE DU TEST" in line and "demo_alu.py" not in line:
            # next demo
            break

        if not in_alu:
            continue

        m = seed_re.search(line.strip())
        if m:
            current_seed = int(m.group(1))
            out.setdefault(current_seed, SeedMetrics())
            continue

        if current_seed is None:
            continue

        m = acc_re.search(line)
        if m:
            raw = m.group(1).strip()
            if raw.endswith("%"):
                out[current_seed].acc = _to_float(raw[:-1])
            else:
                out[current_seed].acc = _to_float(raw)
            continue

        m = mse_re.search(line)
        if m:
            out[current_seed].mse = _to_float(m.group(1))
            continue

    # derive strict pass/fail criterion
    for seed, metrics in out.items():
        if metrics.acc is None:
            continue
        # strict success: 100% accuracy and small MSE
        if metrics.mse is not None:
            metrics.status_success = (metrics.acc >= 99.999) and (metrics.mse <= 0.01)
        else:
            metrics.status_success = metrics.acc >= 99.999

    return out


def parse_half_adder_status(report_text: str) -> Dict[int, SeedMetrics]:
    # Parse Half-Adder success/failure under "DÉMARRAGE DU TEST : demo_logic_gates.py".
    lines = report_text.splitlines()

    in_logic = False
    current_seed: Optional[int] = None

    out: Dict[int, SeedMetrics] = {}

    seed_re = re.compile(r"^Seed\s*=\s*(\d+)")

    for line in lines:
        if "DÉMARRAGE DU TEST : demo_logic_gates.py" in line:
            in_logic = True
            current_seed = None
            continue

        if in_logic and "DÉMARRAGE DU TEST" in line and "demo_logic_gates.py" not in line:
            break

        if not in_logic:
            continue

        m = seed_re.search(line.strip())
        if m:
            current_seed = int(m.group(1))
            out.setdefault(current_seed, SeedMetrics())
            continue

        if current_seed is None:
            continue

        if "-> [SUCCES] Le neurone a appris le Half-Adder" in line:
            out[current_seed].status_success = True
            continue

        if "-> [ECHEC] Le neurone a echoue a apprendre le Half-Adder" in line:
            out[current_seed].status_success = False
            continue

    return out


def _write_csv(path: str, rows: List[Tuple[str, str, str]]):
    with open(path, "w", encoding="utf-8") as f:
        f.write("seed,metric,value\n")
        for seed, metric, value in rows:
            f.write(f"{seed},{metric},{value}\n")


def plot_simple_bars(title: str, x_labels: List[str], y_values: List[float], y_label: str, out_path: str):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(7.5, 3.5))
    ax = fig.add_subplot(1, 1, 1)

    ax.bar(x_labels, y_values)
    ax.set_title(title)
    ax.set_xlabel("Seed")
    ax.set_ylabel(y_label)

    ax.set_ylim(0, max(100.0, max(y_values) * 1.05 if y_values else 1.0))
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)


def plot_success_flags(title: str, x_labels: List[str], flags: List[Optional[bool]], out_path: str):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(7.5, 2.8))
    ax = fig.add_subplot(1, 1, 1)

    y = []
    colors = []
    for f in flags:
        if f is True:
            y.append(1)
            colors.append("#2ca02c")
        elif f is False:
            y.append(0)
            colors.append("#d62728")
        else:
            y.append(0)
            colors.append("#7f7f7f")

    ax.bar(x_labels, y, color=colors)
    ax.set_title(title)
    ax.set_xlabel("Seed")
    ax.set_ylabel("Success")
    ax.set_yticks([0, 1])
    ax.set_ylim(-0.1, 1.1)

    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)


def main():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    liar_dir = os.path.join(base_dir, "Logical Isring-Attractor with Relational-Attention")

    report_path = os.path.join(liar_dir, "rapport_tests_2026-03-14_07h30m07s.txt")
    if not os.path.exists(report_path):
        raise FileNotFoundError(report_path)

    with open(report_path, "r", encoding="utf-8") as f:
        txt = f.read()

    alu = parse_alu_metrics(txt)
    ha = parse_half_adder_status(txt)

    fig_dir = os.path.join(os.path.dirname(__file__), "figures")
    os.makedirs(fig_dir, exist_ok=True)

    seeds = sorted(set(list(alu.keys()) + list(ha.keys())))
    seed_labels = [str(s) for s in seeds]

    alu_acc = [alu.get(s, SeedMetrics()).acc or 0.0 for s in seeds]
    plot_simple_bars(
        title="ALU accuracy by seed (report: 2026-03-14)",
        x_labels=seed_labels,
        y_values=alu_acc,
        y_label="Accuracy (%)",
        out_path=os.path.join(fig_dir, "alu_accuracy_by_seed.png"),
    )

    ha_flags = [ha.get(s, SeedMetrics()).status_success for s in seeds]
    plot_success_flags(
        title="Half-Adder success by seed (demo_logic_gates, report: 2026-03-14)",
        x_labels=seed_labels,
        flags=ha_flags,
        out_path=os.path.join(fig_dir, "half_adder_success_by_seed.png"),
    )

    # Also export CSV for reproducibility.
    rows: List[Tuple[str, str, str]] = []
    for s in seeds:
        m = alu.get(s)
        if m and m.acc is not None:
            rows.append((str(s), "alu_acc", f"{m.acc}"))
        if m and m.mse is not None:
            rows.append((str(s), "alu_mse", f"{m.mse}"))
        h = ha.get(s)
        if h and h.status_success is not None:
            rows.append((str(s), "half_adder_success", "1" if h.status_success else "0"))
    _write_csv(os.path.join(fig_dir, "metrics_report_2026-03-14.csv"), rows)

    print("[OK] Figures written to:")
    print(fig_dir)


if __name__ == "__main__":
    main()
