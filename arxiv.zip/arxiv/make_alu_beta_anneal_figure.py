import os
import csv
from dataclasses import dataclass
from typing import List


@dataclass
class Curve:
    epoch: List[int]
    acc: List[float]
    mse: List[float]
    beta: List[float]


def read_curve(path: str) -> Curve:
    epoch: List[int] = []
    acc: List[float] = []
    mse: List[float] = []
    beta: List[float] = []

    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            epoch.append(int(row["epoch"]))
            acc.append(float(row["acc"]))
            mse.append(float(row["mse"]))
            beta.append(float(row["beta"]))

    return Curve(epoch=epoch, acc=acc, mse=mse, beta=beta)


def main():
    base_dir = os.path.dirname(__file__)
    fig_dir = os.path.join(base_dir, "figures")

    seed = os.environ.get("THERMO_DEMO_SEED", "2")

    csv_no = os.path.join(fig_dir, f"alu_beta_adversarial_seed{seed}_no_anneal.csv")
    csv_yes = os.path.join(fig_dir, f"alu_beta_adversarial_seed{seed}_with_anneal.csv")

    out_png = os.path.join(fig_dir, f"alu_beta_anneal_seed{seed}.png")

    c_no = read_curve(csv_no)
    c_yes = read_curve(csv_yes)

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(9.2, 4.2))

    ax1 = fig.add_subplot(1, 2, 1)
    ax1.plot(c_no.epoch, [a * 100.0 for a in c_no.acc], label="Adversarial beta=5 (no anneal)", color="#d62728")
    ax1.plot(c_yes.epoch, [a * 100.0 for a in c_yes.acc], label="Adversarial + beta anneal", color="#2ca02c")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Accuracy (%)")
    ax1.set_ylim(-2, 102)
    ax1.grid(True, alpha=0.25)
    ax1.legend(loc="lower right", fontsize=8)

    ax2 = fig.add_subplot(1, 2, 2)
    ax2.plot(c_no.epoch, c_no.beta, label="beta (no anneal)", color="#d62728", linestyle="--")
    ax2.plot(c_yes.epoch, c_yes.beta, label="beta (anneal)", color="#2ca02c", linestyle="--")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Beta")
    ax2.grid(True, alpha=0.25)
    ax2.legend(loc="upper right", fontsize=8)

    fig.suptitle(f"ALU seed={seed}: adversarial beta init vs beta annealing")
    fig.tight_layout(rect=[0, 0.02, 1, 0.92])
    fig.savefig(out_png, dpi=200)
    plt.close(fig)

    print("[OK] wrote:")
    print(out_png)


if __name__ == "__main__":
    main()
